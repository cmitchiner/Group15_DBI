import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor() {
        super();
        this.setTitle("Dashboard");
    }

    async getHtml() {
        return `
        <h1> Welcome back, Charlie </h1>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris accumsan nunc vitae augue convallis, efficitur eleifend erat dictum.
        </p>
        <p>
            <a href = "/posts" data-link>View recent posts </a>
        </p>
        `;
    }
}