import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor() {
        super();
        this.setTitle("Dashboard");
    }

    async getHtml() {
        return `
        <h1> Welcome back, Charlie </h1>
        <p>
            Upload csv file.
        </p>
        <form action="/upload" method="POST" enctype="multipart/form-data">
            <input type="file" name="Csv data file" accept=".csv">
            <button>Submit</button>
        </form>
        <p>
            <a href = "/posts" data-link>View recent posts </a>
        </p>
        `;
    }
}