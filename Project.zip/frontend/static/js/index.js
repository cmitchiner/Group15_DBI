import Dashboard from "./views/Dashboard.js";
import Posts from "./views/Posts.js";
import Settings from "./views/Settings.js";

// **** FUNCTION ****
//pathtoRegex: Prevents the page from refreshing when accessing a subpage, more fluid
const pathToRegex = path => new RegExp("^" + path.replace(/\//g, "\\/").replace(/:\w+/g, "(.+)") + "$");

// **** FUNCTION ****
//NavigateTo: Prevents the page from refreshing when accessing a subpage, more fluid
const navigateTo = url => { 
    history.pushState(null,null,url);
    router();
}

// **** FUNCTION ****
//Router: keep's track of the route taken to any subpage
const router = async () => {
    console.log(pathToRegex("/posts/:id")); 
    const routes = [
        { path: "/", view: Dashboard },
        { path: "/posts", view: Posts },
        // { path: "/posts/:id", view: Posts },
        { path: "/settings", view: Settings }
    ];

    // Test each route for potential match
    const potentialMatches = routes.map(route => {
        return {
            route: route,
            isMatch: location.pathname === route.path
        };
    });

    //Get the specific match if isMatch is true
    let match = potentialMatches.find(potentialMatch => potentialMatch.isMatch);

    //Send people to root if they try to access a subpage that doesnt exist
    if (!match) {   
        match = {
            route: routes[0],
            isMatch: true
        };
    }

    //Create a new instance of the view for dashboard at the root
    const view = new match.route.view();

    //Inject the html from our view into the inner html of the app
    document.querySelector("#app").innerHTML = await view.getHtml();
};

//Keeps track of route in console when using a browsers forward and back buttons
window.addEventListener("popstate", router);

document.addEventListener("DOMContentLoaded", () => {
    document.body.addEventListener("click", e => {
        if (e.target.matches("[data-link]"))
        {
            e.preventDefault();           //prevent default behavior of following the link
            navigateTo(e.target.href);    //Instead just jump to subpage without refreshing
        }
    });

    router();
});