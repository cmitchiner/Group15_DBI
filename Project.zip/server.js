//Include express and path libraries
const express = require("express");
const path = require("path");
const app = express();

//Prevent errors when accessing subpages that begin with /static
app.use("/static", express.static(path.resolve(__dirname, "frontend", "static")));

//Tell the webpage the root HTML file
app.get("/*", (req, res) => {
    res.sendFile(path.resolve(__dirname, "frontend", "index.html"));

});

//Send website to local host port 5050 and print server running to console
app.listen(process.env.PORT || 80, () => console.log("Server running..."));