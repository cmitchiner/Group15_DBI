//Include express and path libraries
const express = require("express");
const path = require("path");
const multer = require("multer");
const uuid = require("uuid");

//Formating the uploaded file
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '/uploads/'));
    },
    filename: (req, file, cb) => {
        const { originalname } = file;
        cb(null, 'data.csv');
    }
});
const upload = multer({ storage: storage });

const app = express();
//Prevent errors when accessing subpages that begin with /static
app.use("/static", express.static(path.resolve(__dirname, "frontend", "static")));

//Tell the webpage the root HTML file
app.get("/*", (req, res) => {
    res.sendFile(path.resolve(__dirname, "frontend", "index.html"));

});

//Add the upload function to the website
app.post('/upload', upload.single("Csv data file"), (req, res) => {
    return res.json({ status: 'File successfully uploaded' });
});

//Send website to local host port 5050 and print server running to console
app.listen(process.env.PORT || 80, () => console.log("Server running..."));